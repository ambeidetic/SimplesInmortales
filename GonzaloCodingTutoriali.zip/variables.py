# Numbers
num1 = 6
num2 = 2
num3 = num1 / num2

# strings
string_a = "hola1224"

# Arrays
array = [1,2,3,100]
array2 = ["hello","world", 3, [1,[1,"asd",3],3]]

# Objects
perro = {
    "pelaje": "marron",
    "edad": 5,
    "velocidad": 15.4
}

# boolean
var = True
var2 = False

print(num1 + perro["velocidad"])