inputNumbers = [1, 2, 3, 4, 5]

outputNumbers = []

for number in inputNumbers:
    outputNumbers.append(number * 3)


num = 0

while(num < 10):
    print("Hello")
    num = num + 1

